package com.example.oktademo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OktademoApplicationTests {

	@Test
	void contextLoads() {
	}

}
