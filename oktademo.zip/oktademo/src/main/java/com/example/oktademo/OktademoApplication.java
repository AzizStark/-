package com.example.oktademo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OktademoApplication {

	public static void main(String[] args) {
		SpringApplication.run(OktademoApplication.class, args);
	}

}
